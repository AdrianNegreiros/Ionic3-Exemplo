import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the TestPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-test',
  templateUrl: 'test.html',
})
export class TestPage { //escopo da pagina

  public nome_usuario:string = "Derio Matheus"; //Restringir o valor, variável. Any = Aceita qualquer valor.

  public somaDoisNumeros(num1:number, num2:number): void{ //Garbe collection
    //alert("Minha funcao funcionou...");
    //alert(num1 + num2); //Não colocar entre aspas....
  }

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() { // pontos de execução do ciclo de vida da app.
    //console.log('ionViewDidLoad TestPage');
    this.somaDoisNumeros(15, 790);
  }}  //entra no diretorio
